package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.RestaurantModel;
import com.example.demo.repository.RestaurantServiceRepository;

@Service
public class RestaurantServiceImpl implements RestaurantService {

	@Autowired
	RestaurantServiceRepository restro;

	@Override
	public RestaurantModel getRestaurants(String restaurantName) {
		     
		return restro.getRestaurantByName(restaurantName);
	}

	@Override
	public List<RestaurantModel> displayRestaurants() {
		
		return restro.findAll();
	}

	@Override
	public RestaurantModel getRestaurantByUserId(int id) {
	
		return restro.getRestaurantByUserId(id);
	}

}
