package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Orders;
import com.example.demo.repository.OrdersRepository;

@Service
public class OrderServiceImpl implements OrderService{

	@Autowired
	OrdersRepository repo;
	
	@Override
	public List<Orders> getOrdersByRestaurantId(int id) {
		
		return repo.getOrdersByRestaurantId(id);
	}

	@Override
	public List<Orders> getOrdersByUserId(int id) {
		
		return repo.getOrdersByUserId(id);
	}

	@Override
	public Orders getOrderByOrderId(int id) {
		
		return repo.findById(id).get();
	}

	@Override
	public Orders createOrder(Orders order) {
	
		return repo.save(order);
	}

	@Override
	public Orders updateOrder(int id, Orders order) {
		order.setOrderid(id);
		return repo.save(order);
	}

	

}
